CREATE -- POST -- Make New
RETRIEVE -- GET -- List / Search
UPDATE -- PUT/PATCH -- Edit
DELETE -- DELETE -- Delete

